import { Component, inject, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { ClinicalService } from '../../services/clinical.service';
import { User } from '../../models/auth.model';

@Component({
  selector: 'app-users',
  standalone: true,
  imports: [CommonModule, DatePipe],
  template: `
    <div class="module-container">
      <div class="module-head">
        <div>
          <h2>Usuarios del Sistema</h2>
          <p class="subtitle">Control de accesos y roles (Exclusivo para Administradores).</p>
        </div>

        <div class="admin-badge">
          <span>🔐 Módulo de Seguridad</span>
        </div>
      </div>

      <!-- Tabla de Usuarios -->
      <div class="table-card">
        @if (loading) {
          <div class="table-loading">
            <span class="spinner"></span>
            <span>Cargando cuentas de usuario...</span>
          </div>
        } @else {
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Usuario</th>
                  <th>Correo Electrónico</th>
                  <th>Rol Asignado</th>
                  <th>Último Acceso</th>
                  <th>Estado</th>
                </tr>
              </thead>
              <tbody>
                @for (u of users; track u.user_id) {
                  <tr>
                    <td><strong>#{{ u.user_id }}</strong></td>
                    <td>
                      <div class="user-row">
                        <div class="user-avatar-circle">{{ u.username.charAt(0).toUpperCase() }}</div>
                        <strong>{{ u.username }}</strong>
                      </div>
                    </td>
                    <td>{{ u.email }}</td>
                    <td>
                      <span class="role-pill" [ngClass]="u.role">
                        {{ translateRole(u.role) }}
                      </span>
                    </td>
                    <td>
                      {{ u.last_login ? (u.last_login | date:'dd/MM/yyyy HH:mm') : 'Sin registros' }}
                    </td>
                    <td>
                      <span class="badge" [class.badge-active]="u.is_active" [class.badge-inactive]="!u.is_active">
                        {{ u.is_active ? 'Activo' : 'Inactivo' }}
                      </span>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    .module-container { display: flex; flex-direction: column; gap: 20px; }
    .module-head { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; }
    .module-head h2 { margin: 0 0 4px 0; font-size: 22px; font-weight: 800; color: #0f172a; }
    .subtitle { margin: 0; font-size: 13px; color: #64748b; }

    .admin-badge {
      padding: 6px 14px; border-radius: 999px; background: #fef3c7; border: 1px solid #fde68a;
      color: #b45309; font-size: 12px; font-weight: 700;
    }

    .table-card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; }
    .table-responsive { overflow-x: auto; }
    .data-table { width: 100%; border-collapse: collapse; text-align: left; font-size: 13px; }
    .data-table th { padding: 12px 16px; font-weight: 600; color: #64748b; background: #f8fafc; border-bottom: 1px solid #e2e8f0; font-size: 12px; text-transform: uppercase; }
    .data-table td { padding: 14px 16px; border-bottom: 1px solid #f1f5f9; color: #334155; }

    .user-row { display: flex; align-items: center; gap: 10px; }
    .user-avatar-circle {
      width: 32px; height: 32px; border-radius: 50%; background: #e0f2fe; color: #0369a1;
      font-weight: 700; display: grid; place-items: center; font-size: 13px;
    }

    .role-pill {
      display: inline-block; padding: 4px 10px; border-radius: 6px; font-size: 11px; font-weight: 700;
      text-transform: uppercase; letter-spacing: 0.05em;
    }
    .role-pill.admin { background: #fef3c7; color: #b45309; }
    .role-pill.veterinarian { background: #ccfbf1; color: #0f766e; }
    .role-pill.receptionist { background: #dbeafe; color: #1e40af; }

    .badge { display: inline-block; padding: 3px 9px; border-radius: 999px; font-size: 11px; font-weight: 600; }
    .badge-active { background: #d1fae5; color: #065f46; }
    .badge-inactive { background: #fee2e2; color: #991b1b; }

    .table-loading { padding: 50px 20px; text-align: center; color: #64748b; display: flex; flex-direction: column; align-items: center; gap: 12px; }
    .spinner { width: 24px; height: 24px; border: 3px solid #e2e8f0; border-top-color: #0d9488; border-radius: 50%; animation: spin 0.8s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }
  `]
})
export class UsersComponent implements OnInit {
  private clinicalService = inject(ClinicalService);

  users: User[] = [];
  loading = true;

  ngOnInit(): void {
    this.clinicalService.listUsers(1, 50).subscribe({
      next: (res) => {
        this.users = res.items;
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }

  translateRole(role: string): string {
    switch (role) {
      case 'admin': return 'Administrador';
      case 'veterinarian': return 'Médico Veterinario';
      case 'receptionist': return 'Recepcionista';
      default: return role;
    }
  }
}
