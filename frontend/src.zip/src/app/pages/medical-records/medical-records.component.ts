import { Component, inject, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ClinicalService } from '../../services/clinical.service';
import { PetService } from '../../services/pet.service';
import { VeterinarianService } from '../../services/veterinarian.service';
import {
  MedicalRecord,
  Consultation,
  Pet,
  Veterinarian,
  ConsultationType
} from '../../models/entities.model';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-medical-records',
  standalone: true,
  imports: [CommonModule, FormsModule, DatePipe],
  template: `
    <div class="module-container">
      <div class="module-head">
        <div>
          <h2>Historias Clínicas & Consultas</h2>
          <p class="subtitle">Expedientes clínicos, constantes vitales y registros médicos de pacientes.</p>
        </div>

        <button class="btn-primary" (click)="openNewConsultationModal()" [disabled]="!selectedRecord">
          <span class="btn-icon">+</span> Registrar Nueva Consulta
        </button>
      </div>

      <!-- Selector de Paciente / Historia Clínica -->
      <div class="selector-card">
        <label>Selecciona un Paciente para ver su Historia Clínica:</label>
        <div class="selector-row">
          <select [(ngModel)]="selectedRecordId" (change)="onRecordChange()" class="main-select">
            <option [ngValue]="null" disabled>-- Selecciona un Paciente --</option>
            @for (r of records; track r.medical_record_id) {
              <option [ngValue]="r.medical_record_id">
                🐾 Paciente: {{ r.pet?.name || ('#' + r.pet_id) }} &bull; Historia #{{ r.medical_record_id }} (Apertura: {{ r.opened_on | date:'dd/MM/yyyy' }})
              </option>
            }
          </select>
        </div>
      </div>

      @if (loadingRecord) {
        <div class="loading-state">
          <span class="spinner"></span>
          <span>Cargando expediente clínico...</span>
        </div>
      } @else if (selectedRecord) {
        <!-- Ficha de la Historia Clínica -->
        <div class="record-overview-card">
          <div class="overview-header">
            <div class="record-badge">
              <span> Historia Clínica #{{ selectedRecord.medical_record_id }}</span>
            </div>
            <span class="opened-date">
              Fecha de Apertura: <strong>{{ selectedRecord.opened_on | date:'dd/MM/yyyy' }}</strong>
            </span>
          </div>

          <div class="overview-body">
            <div class="patient-pill">
              <span class="icon"></span>
              <div>
                <strong>{{ selectedRecord.pet?.name || ('Paciente #' + selectedRecord.pet_id) }}</strong>
                <span>ID Paciente: {{ selectedRecord.pet_id }}</span>
              </div>
            </div>

            <div class="notes-box">
              <span class="notes-title">Observaciones Clínicas Generales:</span>
              <p>{{ selectedRecord.general_notes || 'Sin antecedentes clínicos patológicos registrados en la apertura.' }}</p>
            </div>
          </div>
        </div>

        <!-- Historial de Consultas Realizadas -->
        <div class="consultations-section">
          <div class="section-head">
            <h3>Consultas Realizadas ({{ consultations.length }})</h3>
            <span class="section-sub">Atenciones clínicas, diagnósticos y constantes vitales</span>
          </div>

          @if (loadingConsultations) {
            <div class="loading-state">
              <span class="spinner"></span>
              <span>Cargando historial de atenciones...</span>
            </div>
          } @else if (consultations.length === 0) {
            <div class="empty-consultations">
              <p>No se han registrado consultas médicas para esta historia clínica.</p>
              <button class="btn-primary" (click)="openNewConsultationModal()">+ Registrar Primera Consulta</button>
            </div>
          } @else {
            <div class="timeline">
              @for (c of consultations; track c.consultation_id) {
                <div class="timeline-item">
                  <div class="timeline-dot"></div>
                  <div class="timeline-card">
                    <div class="card-top">
                      <div>
                        <span class="consultation-type-badge">{{ translateType(c.consultation_type) }}</span>
                        <strong class="consultation-date">{{ c.consultation_date | date:'dd/MM/yyyy HH:mm' }}</strong>
                      </div>
                      <span class="attending-vet">
                        🩺 Atendido por: <strong>Dr(a). {{ c.vet?.first_name || ('Vet #' + c.vet_id) }} {{ c.vet?.last_name || '' }}</strong>
                      </span>
                    </div>

                    <!-- Constantes vitales medidas en consulta -->
                    <div class="vitals-grid">
                      <div class="vital-item">
                        <span class="v-label"> Peso</span>
                        <span class="v-val">{{ c.weight_kg ? c.weight_kg + ' kg' : '—' }}</span>
                      </div>
                      <div class="vital-item">
                        <span class="v-label">Temperatura</span>
                        <span class="v-val">{{ c.temperature_c ? c.temperature_c + ' °C' : '—' }}</span>
                      </div>
                      <div class="vital-item">
                        <span class="v-label"> Ritmo Cardíaco</span>
                        <span class="v-val">{{ c.heart_rate ? c.heart_rate + ' lpm' : '—' }}</span>
                      </div>
                      <div class="vital-item">
                        <span class="v-label"> Frecuencia Resp.</span>
                        <span class="v-val">{{ c.respiratory_rate ? c.respiratory_rate + ' rpm' : '—' }}</span>
                      </div>
                    </div>

                    <!-- Anamnesis y Diagnóstico -->
                    <div class="clinical-details">
                      @if (c.anamnesis) {
                        <div class="clinical-block">
                          <strong>Anamnesis / Síntomas reportados:</strong>
                          <p>{{ c.anamnesis }}</p>
                        </div>
                      }

                      @if (c.diagnosis) {
                        <div class="clinical-block diagnosis">
                          <strong>Diagnóstico Definitivo:</strong>
                          <p>{{ c.diagnosis }}</p>
                        </div>
                      }

                      @if (c.treatment_plan) {
                        <div class="clinical-block treatment">
                          <strong>Plan de Tratamiento & Receta:</strong>
                          <p>{{ c.treatment_plan }}</p>
                        </div>
                      }
                    </div>
                  </div>
                </div>
              }
            </div>
          }
        </div>
      } @else {
        <div class="select-prompt">
          <span class="prompt-icon">📋</span>
          <h3>Selecciona una historia clínica arriba</h3>
          <p>Podrás inspeccionar consultas anteriores, registrar diagnósticos, recetas y signos vitales.</p>
        </div>
      }

      <!-- Modal para Registrar Nueva Consulta -->
      @if (consultationModalOpen) {
        <div class="modal-backdrop" (click)="closeModalOnBackdrop($event)">
          <div class="modal-dialog">
            <div class="modal-head">
              <h3>Registrar Atención / Consulta Médica</h3>
              <button class="btn-close" (click)="consultationModalOpen = false">&times;</button>
            </div>

            <form (ngSubmit)="saveConsultation()" class="modal-form">
              <div class="form-grid-2">
                <div class="form-group">
                  <label>Médico Veterinario <span class="required">*</span></label>
                  <select [(ngModel)]="consultationForm.vet_id" name="vet_id" required>
                    <option [ngValue]="undefined" disabled>-- Selecciona un Médico --</option>
                    @for (v of vets; track v.vet_id) {
                      <option [ngValue]="v.vet_id">
                        Dr(a). {{ v.first_name }} {{ v.last_name }}
                      </option>
                    }
                  </select>
                </div>

                <div class="form-group">
                  <label>Tipo de Atención <span class="required">*</span></label>
                  <select [(ngModel)]="consultationForm.consultation_type" name="consultation_type" required>
                    <option value="checkup">Chequeo General</option>
                    <option value="vaccination">Vacunación</option>
                    <option value="emergency">Urgencia / Emergencia</option>
                    <option value="surgery">Cirugía</option>
                    <option value="follow_up">Control / Seguimiento</option>
                    <option value="other">Otro</option>
                  </select>
                </div>
              </div>

              <!-- Constantes Vitales -->
              <div class="vitals-form-grid">
                <div class="form-group">
                  <label>Peso (kg)</label>
                  <input type="number" step="0.1" [(ngModel)]="consultationForm.weight_kg" name="weight_kg" placeholder="ej: 12.5" />
                </div>
                <div class="form-group">
                  <label>Temperatura (°C)</label>
                  <input type="number" step="0.1" [(ngModel)]="consultationForm.temperature_c" name="temperature_c" placeholder="ej: 38.5" />
                </div>
                <div class="form-group">
                  <label>Ritmo Cardíaco (lpm)</label>
                  <input type="number" [(ngModel)]="consultationForm.heart_rate" name="heart_rate" placeholder="ej: 110" />
                </div>
                <div class="form-group">
                  <label>Frecuencia Resp. (rpm)</label>
                  <input type="number" [(ngModel)]="consultationForm.respiratory_rate" name="respiratory_rate" placeholder="ej: 25" />
                </div>
              </div>

              <div class="form-group">
                <label>Anamnesis (Motivo de consulta y síntomas)</label>
                <textarea [(ngModel)]="consultationForm.anamnesis" name="anamnesis" rows="2" placeholder="Paciente presenta inapetencia desde hace 2 días..."></textarea>
              </div>

              <div class="form-group">
                <label>Diagnóstico</label>
                <textarea [(ngModel)]="consultationForm.diagnosis" name="diagnosis" rows="2" placeholder="Gastroenteritis leve..."></textarea>
              </div>

              <div class="form-group">
                <label>Plan de Tratamiento e Indicaciones</label>
                <textarea [(ngModel)]="consultationForm.treatment_plan" name="treatment_plan" rows="2" placeholder="Administrar probióticos cada 12 horas por 5 días..."></textarea>
              </div>

              <div class="modal-actions">
                <button type="button" class="btn-secondary" (click)="consultationModalOpen = false">Cancelar</button>
                <button type="submit" class="btn-primary" [disabled]="saving || !consultationForm.vet_id">
                  {{ saving ? 'Registrando...' : 'Guardar Consulta' }}
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .module-container { display: flex; flex-direction: column; gap: 20px; }
    .module-head { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; }
    .module-head h2 { margin: 0 0 4px 0; font-size: 22px; font-weight: 800; color: #0f172a; }
    .subtitle { margin: 0; font-size: 13px; color: #64748b; }

    .btn-primary {
      padding: 10px 18px; border-radius: 10px; border: none;
      background: linear-gradient(135deg, #0d9488, #0f766e);
      color: #ffffff; font-size: 14px; font-weight: 600; cursor: pointer;
      display: inline-flex; align-items: center; gap: 6px;
      box-shadow: 0 4px 12px rgba(13, 148, 136, 0.25);
    }
    .btn-primary:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 6px 16px rgba(13, 148, 136, 0.35); }
    .btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
    .btn-icon { font-size: 16px; font-weight: 700; }

    .selector-card {
      background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; padding: 18px 22px;
      display: flex; flex-direction: column; gap: 10px;
    }
    .selector-card label { font-size: 13px; font-weight: 700; color: #334155; }
    .main-select {
      width: 100%; padding: 12px 14px; border: 1px solid #cbd5e1; border-radius: 10px; font-size: 14px;
      background: #f8fafc; color: #0f172a; font-weight: 600; outline: none;
    }
    .main-select:focus { border-color: #0d9488; box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.15); }

    .record-overview-card {
      background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; padding: 22px;
      display: flex; flex-direction: column; gap: 16px;
    }
    .overview-header {
      display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #f1f5f9; padding-bottom: 12px;
    }
    .record-badge { font-size: 15px; font-weight: 800; color: #0f766e; }
    .opened-date { font-size: 13px; color: #64748b; }
    .overview-body { display: flex; gap: 24px; flex-wrap: wrap; }
    .patient-pill {
      display: flex; align-items: center; gap: 12px; background: #f0fdfa; border: 1px solid #ccfbf1;
      padding: 12px 16px; border-radius: 12px;
    }
    .patient-pill .icon { font-size: 24px; }
    .patient-pill div { display: flex; flex-direction: column; }
    .patient-pill strong { font-size: 15px; color: #0f172a; }
    .patient-pill span { font-size: 12px; color: #64748b; }
    .notes-box { flex: 1; min-width: 280px; }
    .notes-title { font-size: 12px; font-weight: 700; color: #64748b; text-transform: uppercase; }
    .notes-box p { margin: 4px 0 0; font-size: 13px; color: #334155; line-height: 1.5; }

    .consultations-section { display: flex; flex-direction: column; gap: 16px; margin-top: 10px; }
    .section-head h3 { margin: 0; font-size: 17px; font-weight: 800; color: #0f172a; }
    .section-sub { font-size: 13px; color: #64748b; }

    .timeline { display: flex; flex-direction: column; gap: 16px; position: relative; padding-left: 20px; }
    .timeline::before {
      content: ''; position: absolute; left: 6px; top: 12px; bottom: 12px; width: 2px; background: #e2e8f0;
    }
    .timeline-item { position: relative; }
    .timeline-dot {
      position: absolute; left: -20px; top: 18px; width: 14px; height: 14px; border-radius: 50%;
      background: #0d9488; border: 3px solid #ffffff; box-shadow: 0 0 0 2px #ccfbf1;
    }
    .timeline-card {
      background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; padding: 18px 20px;
      display: flex; flex-direction: column; gap: 14px;
    }
    .card-top { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; }
    .consultation-type-badge {
      display: inline-block; padding: 3px 8px; border-radius: 6px; background: #e0f2fe; color: #0369a1;
      font-size: 11px; font-weight: 700; text-transform: uppercase; margin-right: 8px;
    }
    .consultation-date { font-size: 14px; color: #0f172a; }
    .attending-vet { font-size: 13px; color: #475569; }

    .vitals-grid {
      display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 10px;
      background: #f8fafc; border: 1px solid #f1f5f9; border-radius: 10px; padding: 10px 14px;
    }
    .vital-item { display: flex; flex-direction: column; gap: 2px; }
    .v-label { font-size: 11px; color: #64748b; font-weight: 600; }
    .v-val { font-size: 14px; font-weight: 700; color: #0f172a; }

    .clinical-details { display: flex; flex-direction: column; gap: 10px; }
    .clinical-block { font-size: 13px; line-height: 1.5; color: #334155; }
    .clinical-block strong { display: block; color: #0f172a; margin-bottom: 2px; }
    .clinical-block p { margin: 0; }
    .clinical-block.diagnosis { background: #fefce8; border-left: 3px solid #eab308; padding: 8px 12px; border-radius: 4px; }
    .clinical-block.treatment { background: #f0fdf4; border-left: 3px solid #22c55e; padding: 8px 12px; border-radius: 4px; }

    .select-prompt, .empty-consultations {
      padding: 60px 20px; text-align: center; color: #64748b; background: #ffffff; border: 1px solid #e2e8f0;
      border-radius: 14px; display: flex; flex-direction: column; align-items: center; gap: 12px;
    }
    .prompt-icon { font-size: 42px; }
    .loading-state { padding: 40px; text-align: center; display: flex; flex-direction: column; align-items: center; gap: 12px; color: #64748b; }
    .spinner { width: 24px; height: 24px; border: 3px solid #e2e8f0; border-top-color: #0d9488; border-radius: 50%; animation: spin 0.8s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }

    /* Modal */
    .modal-backdrop { position: fixed; inset: 0; background: rgba(15, 23, 42, 0.55); backdrop-filter: blur(4px); z-index: 9998; display: grid; place-items: center; padding: 16px; }
    .modal-dialog { background: #ffffff; width: min(650px, 100%); border-radius: 18px; padding: 26px; box-shadow: 0 25px 50px -12px rgba(15, 23, 42, 0.25); max-height: 90vh; overflow-y: auto; }
    .modal-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid #f1f5f9; padding-bottom: 12px; }
    .modal-head h3 { margin: 0; font-size: 18px; font-weight: 800; color: #0f172a; }
    .btn-close { background: transparent; border: none; font-size: 24px; color: #94a3b8; cursor: pointer; }
    .modal-form { display: flex; flex-direction: column; gap: 14px; }
    .form-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
    .vitals-form-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; }
    .form-group { display: flex; flex-direction: column; gap: 6px; }
    .form-group label { font-size: 13px; font-weight: 600; color: #334155; }
    .required { color: #ef4444; }
    .form-group input, .form-group select, .form-group textarea {
      padding: 9px 12px; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 13px; outline: none; background: #ffffff; font-family: inherit;
    }
    .form-group input:focus, .form-group select:focus, .form-group textarea:focus { border-color: #0d9488; box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.15); }
    .modal-actions { margin-top: 16px; display: flex; justify-content: flex-end; gap: 12px; }
    .btn-secondary { padding: 9px 16px; border-radius: 8px; border: 1px solid #cbd5e1; background: #ffffff; color: #334155; font-weight: 600; cursor: pointer; }
    @media (max-width: 650px) {
      .vitals-form-grid { grid-template-columns: 1fr 1fr; }
      .form-grid-2 { grid-template-columns: 1fr; }
    }
  `]
})
export class MedicalRecordsComponent implements OnInit {
  private clinicalService = inject(ClinicalService);
  private vetService = inject(VeterinarianService);
  private toast = inject(ToastService);

  records: MedicalRecord[] = [];
  vets: Veterinarian[] = [];

  selectedRecordId: number | null = null;
  selectedRecord: MedicalRecord | null = null;
  consultations: Consultation[] = [];

  loadingRecord = false;
  loadingConsultations = false;
  consultationModalOpen = false;
  saving = false;

  consultationForm: any = {
    consultation_type: 'checkup'
  };

  ngOnInit(): void {
    this.loadVets();
    this.loadRecords();
  }

  loadVets() {
    this.vetService.list(1, 50).subscribe({
      next: res => this.vets = res.items
    });
  }

  loadRecords() {
    this.clinicalService.listMedicalRecords(1, 100).subscribe({
      next: (res) => {
        this.records = res.items;
        if (this.records.length > 0) {
          this.selectedRecordId = this.records[0].medical_record_id;
          this.onRecordChange();
        }
      }
    });
  }

  onRecordChange() {
    if (!this.selectedRecordId) return;

    this.loadingRecord = true;
    this.selectedRecord = this.records.find(r => r.medical_record_id === this.selectedRecordId) || null;
    this.loadingRecord = false;

    this.loadConsultations(this.selectedRecordId);
  }

  loadConsultations(recordId: number) {
    this.loadingConsultations = true;
    this.clinicalService.listConsultations(1, 50, recordId).subscribe({
      next: (res) => {
        this.consultations = res.items;
        this.loadingConsultations = false;
      },
      error: () => this.loadingConsultations = false
    });
  }

  translateType(type: ConsultationType): string {
    switch (type) {
      case 'checkup': return 'Chequeo General';
      case 'vaccination': return 'Vacunación';
      case 'emergency': return 'Urgencia Médica';
      case 'surgery': return 'Procedimiento Quirúrgico';
      case 'follow_up': return 'Control Post-Tratamiento';
      default: return type;
    }
  }

  openNewConsultationModal() {
    if (!this.selectedRecord) return;

    this.consultationForm = {
      medical_record_id: this.selectedRecord.medical_record_id,
      vet_id: this.vets.length ? this.vets[0].vet_id : undefined,
      consultation_type: 'checkup',
      weight_kg: null,
      temperature_c: null,
      heart_rate: null,
      respiratory_rate: null,
      anamnesis: '',
      diagnosis: '',
      treatment_plan: ''
    };
    this.consultationModalOpen = true;
  }

  closeModalOnBackdrop(event: MouseEvent) {
    if ((event.target as HTMLElement).classList.contains('modal-backdrop')) {
      this.consultationModalOpen = false;
    }
  }

  saveConsultation() {
    if (!this.consultationForm.vet_id) {
      this.toast.error('Debe seleccionar un médico veterinario.');
      return;
    }

    this.saving = true;

    this.clinicalService.createConsultation(this.consultationForm).subscribe({
      next: () => {
        this.toast.success('Consulta clínica registrada correctamente en el expediente.');
        this.saving = false;
        this.consultationModalOpen = false;
        if (this.selectedRecordId) {
          this.loadConsultations(this.selectedRecordId);
        }
      },
      error: (err) => {
        this.saving = false;
        this.toast.error(err.error?.detail || 'No se pudo guardar la consulta.');
      }
    });
  }
}
