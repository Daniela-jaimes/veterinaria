import { Component, inject, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AppointmentService } from '../../services/appointment.service';
import { PetService } from '../../services/pet.service';
import { VeterinarianService } from '../../services/veterinarian.service';
import {
  Appointment,
  AppointmentStatus,
  Pet,
  Veterinarian
} from '../../models/entities.model';
import { ToastService } from '../../services/toast.service';
import { ConfirmModalComponent } from '../../components/confirm-modal/confirm-modal.component';

@Component({
  selector: 'app-appointments',
  standalone: true,
  imports: [CommonModule, FormsModule, DatePipe, ConfirmModalComponent],
  template: `
    <div class="module-container">
      <div class="module-head">
        <div>
          <h2>Agenda y Citas Veterinarias</h2>
          <p class="subtitle">Programación de turnos de atención y seguimiento clínico.</p>
        </div>

        <button class="btn-primary" (click)="openCreateModal()">
          <span class="btn-icon">+</span> Agendar Nueva Cita
        </button>
      </div>

      <!-- Barra de Filtros por Estado -->
      <div class="tabs-bar">
        <button
          class="tab-btn"
          [class.active]="!selectedStatus"
          (click)="filterByStatus(undefined)"
        >
          Todas las Citas
        </button>
        <button
          class="tab-btn"
          [class.active]="selectedStatus === 'scheduled'"
          (click)="filterByStatus('scheduled')" >
        </button>
        <button
          class="tab-btn"
          [class.active]="selectedStatus === 'in_consultation'"
          (click)="filterByStatus('in_consultation')"
        >
          🩺 En Consulta
        </button>
        <button
          class="tab-btn"
          [class.active]="selectedStatus === 'completed'"
          (click)="filterByStatus('completed')"
        >
          ✓ Completadas
        </button>
        <button
          class="tab-btn"
          [class.active]="selectedStatus === 'cancelled'"
          (click)="filterByStatus('cancelled')"
        >
          ✗ Canceladas
        </button>
      </div>

      <!-- Tabla de Citas -->
      <div class="table-card">
        @if (loading) {
          <div class="table-loading">
            <span class="spinner"></span>
            <span>Cargando agenda de citas...</span>
          </div>
        } @else if (appointments.length === 0) {
          <div class="table-empty">
            <h3>No hay citas en este estado</h3>
            <p>Puedes programar una nueva cita con fecha actual o futura.</p>
            <button class="btn-primary" (click)="openCreateModal()">+ Agendar Cita</button>
          </div>
        } @else {
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Fecha & Hora</th>
                  <th>Paciente</th>
                  <th>Veterinario Asignado</th>
                  <th>Motivo</th>
                  <th>Duración</th>
                  <th>Estado</th>
                  <th class="th-actions">Acciones</th>
                </tr>
              </thead>
              <tbody>
                @for (a of appointments; track a.appointment_id) {
                  <tr>
                    <td class="font-medium">
                      {{ a.scheduled_at | date:'dd/MM/yyyy HH:mm' }}
                    </td>
                    <td>
                      <div class="patient-cell">
                        <strong>🐾 {{ a.pet?.name || ('Paciente #' + a.pet_id) }}</strong>
                        <small class="text-muted">ID: #{{ a.pet_id }}</small>
                      </div>
                    </td>
                    <td>
                      <div class="vet-cell">
                        <span>Dr(a). {{ a.vet?.first_name || ('Vet #' + a.vet_id) }} {{ a.vet?.last_name || '' }}</span>
                      </div>
                    </td>
                    <td>
                      <span class="reason-text">{{ a.reason || 'Consulta General' }}</span>
                    </td>
                    <td>
                      <span class="duration-badge">{{ a.duration_minutes || 30 }} min</span>
                    </td>
                    <td>
                      <span class="status-pill" [ngClass]="'status-' + a.status">
                        {{ translateStatus(a.status) }}
                      </span>
                    </td>
                    <td class="td-actions">
                      @if (a.status === 'scheduled') {
                        <button
                          class="btn-status-action btn-in-consultation"
                          (click)="changeStatus(a, 'in_consultation')"
                          title="Iniciar Consulta"
                        >
                    
                        </button>
                      } @else if (a.status === 'in_consultation') {
                        <button
                          class="btn-status-action btn-complete"
                          (click)="changeStatus(a, 'completed')"
                          title="Finalizar Consulta"
                        >
                    
                        </button>
                      }

                      <button class="btn-table-edit" (click)="openEditModal(a)" title="Editar Cita">
    
                      </button>

                      @if (a.status !== 'cancelled' && a.status !== 'completed') {
                        <button class="btn-table-delete" (click)="promptCancel(a)" title="Cancelar Cita">
                        </button>
                      }
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>

          <!-- Paginación -->
          <div class="pagination-footer">
            <div class="pagination-info">
              Página <strong>{{ currentPage }}</strong> de {{ totalPages }} (Total: <strong>{{ totalRecords }}</strong> citas)
            </div>
            <div class="pagination-buttons">
              <button
                class="btn-pager"
                [disabled]="currentPage <= 1 || loading"
                (click)="loadPage(currentPage - 1)"
              >
                &larr; Anterior
              </button>
              <button
                class="btn-pager"
                [disabled]="currentPage >= totalPages || loading"
                (click)="loadPage(currentPage + 1)"
              >
                Siguiente &rarr;
              </button>
            </div>
          </div>
        }
      </div>

      <!-- Modal de Agendar / Reprogramar Cita -->
      @if (modalOpen) {
        <div class="modal-backdrop" (click)="closeModalOnBackdrop($event)">
          <div class="modal-dialog">
            <div class="modal-head">
              <h3>{{ isEditing ? 'Reprogramar / Editar Cita' : 'Agendar Nueva Cita' }}</h3>
              <button class="btn-close" (click)="modalOpen = false">&times;</button>
            </div>

            <form (ngSubmit)="saveAppointment()" class="modal-form">
              <!-- Selectores de Mascota y Veterinario -->
              <div class="form-grid-2">
                <div class="form-group">
                  <label>Paciente (Mascota) <span class="required">*</span></label>
                  <select [(ngModel)]="formData.pet_id" name="pet_id" required [disabled]="isEditing">
                    <option [ngValue]="undefined" disabled>-- Selecciona un Paciente --</option>
                    @for (p of petOptions; track p.pet_id) {
                      <option [ngValue]="p.pet_id">
                        🐾 {{ p.name }} (ID #{{ p.pet_id }})
                      </option>
                    }
                  </select>
                </div>

                <div class="form-group">
                  <label>Médico Veterinario <span class="required">*</span></label>
                  <select [(ngModel)]="formData.vet_id" name="vet_id" required>
                    <option [ngValue]="undefined" disabled>-- Selecciona un Médico --</option>
                    @for (v of vetOptions; track v.vet_id) {
                      <option [ngValue]="v.vet_id">
                        🩺 Dr(a). {{ v.first_name }} {{ v.last_name }}
                      </option>
                    }
                  </select>
                </div>
              </div>

              <!-- Fecha y Hora con validación de no agendar en el pasado -->
              <div class="form-grid-2">
                <div class="form-group">
                  <label>Fecha y Hora <span class="required">*</span></label>
                  <input
                    type="datetime-local"
                    [(ngModel)]="formData.scheduled_at"
                    name="scheduled_at"
                    required
                    [min]="isEditing ? '' : minDateTime"
                  />
                  <small class="hint-text">Regla de negocio: No se permiten fechas pasadas.</small>
                </div>

                <div class="form-group">
                  <label>Duración Estimada (Minutos)</label>
                  <input
                    type="number"
                    [(ngModel)]="formData.duration_minutes"
                    name="duration_minutes"
                    min="15"
                    max="240"
                    step="15"
                  />
                </div>
              </div>

              <div class="form-group">
                <label>Motivo de la Cita</label>
                <input
                  type="text"
                  [(ngModel)]="formData.reason"
                  name="reason"
                  placeholder="ej: Vacunación anual, chequeo general, vómito persistente"
                />
              </div>

              <div class="form-group">
                <label>Notas u Observaciones Previas</label>
                <textarea
                  [(ngModel)]="formData.notes"
                  name="notes"
                  rows="2"
                  placeholder="Instrucciones adicionales para el tutor o el médico..."
                ></textarea>
              </div>

              @if (isEditing) {
                <div class="form-group">
                  <label>Estado de la Cita</label>
                  <select [(ngModel)]="formData.status" name="status">
                    <option value="scheduled">Agendada</option>
                    <option value="in_consultation">En Consulta</option>
                    <option value="completed">Completada</option>
                    <option value="cancelled">Cancelada</option>
                    <option value="no_show">No Asistió</option>
                  </select>
                </div>
              }

              <div class="modal-actions">
                <button type="button" class="btn-secondary" (click)="modalOpen = false">
                  Cancelar
                </button>
                <button
                  type="submit"
                  class="btn-primary"
                  [disabled]="saving || !formData.pet_id || !formData.vet_id || !formData.scheduled_at"
                >
                  {{ saving ? 'Guardando...' : (isEditing ? 'Actualizar Cita' : 'Confirmar Cita') }}
                </button>
              </div>
            </form>
          </div>
        </div>
      }

      <!-- Modal de Cancelación de Cita -->
      <app-confirm-modal
        [isOpen]="confirmCancelOpen"
        title="¿Cancelar Cita Veterinaria?"
        [message]="'¿Estás seguro de que deseas cancelar la cita del paciente ' + (appointmentToCancel?.pet?.name || '#' + appointmentToCancel?.pet_id) + '?'"
        details="El horario quedará liberado en la agenda para nuevos pacientes."
        confirmText="Sí, Cancelar Cita"
        cancelText="Conservar Cita"
        (confirm)="executeCancel()"
        (cancel)="confirmCancelOpen = false"
      />
    </div>
  `,
  styles: [`
    .module-container { display: flex; flex-direction: column; gap: 20px; }
    .module-head { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; }
    .module-head h2 { margin: 0 0 4px 0; font-size: 22px; font-weight: 800; color: #0f172a; }
    .subtitle { margin: 0; font-size: 13px; color: #64748b; }

    .btn-primary {
      padding: 10px 18px; border-radius: 10px; border: none;
      background: linear-gradient(135deg, #0d9488, #0f766e);
      color: #ffffff; font-size: 14px; font-weight: 600; cursor: pointer;
      display: inline-flex; align-items: center; gap: 6px;
      box-shadow: 0 4px 12px rgba(13, 148, 136, 0.25);
    }
    .btn-primary:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 6px 16px rgba(13, 148, 136, 0.35); }
    .btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }
    .btn-icon { font-size: 16px; font-weight: 700; }

    .tabs-bar {
      display: flex; gap: 8px; overflow-x: auto; padding-bottom: 2px;
    }
    .tab-btn {
      padding: 9px 16px; border-radius: 10px; border: 1px solid #e2e8f0;
      background: #ffffff; color: #475569; font-size: 13px; font-weight: 600;
      cursor: pointer; transition: all 0.15s ease; white-space: nowrap;
    }
    .tab-btn:hover { background: #f8fafc; border-color: #cbd5e1; }
    .tab-btn.active {
      background: #0d9488; color: #ffffff; border-color: #0d9488;
      box-shadow: 0 2px 6px rgba(13, 148, 136, 0.25);
    }

    .table-card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; }
    .table-responsive { overflow-x: auto; }
    .data-table { width: 100%; border-collapse: collapse; text-align: left; font-size: 13px; }
    .data-table th { padding: 12px 16px; font-weight: 600; color: #64748b; background: #f8fafc; border-bottom: 1px solid #e2e8f0; font-size: 12px; text-transform: uppercase; }
    .data-table td { padding: 14px 16px; border-bottom: 1px solid #f1f5f9; color: #334155; }
    .font-medium { font-weight: 600; color: #0f172a; }

    .patient-cell, .vet-cell { display: flex; flex-direction: column; gap: 2px; }
    .text-muted { font-size: 11px; color: #94a3b8; }
    .duration-badge { font-size: 12px; font-weight: 500; color: #64748b; }

    .status-pill { display: inline-block; padding: 3px 9px; border-radius: 999px; font-size: 11px; font-weight: 600; }
    .status-scheduled { background: #dbeafe; color: #1e40af; }
    .status-in_consultation { background: #fef3c7; color: #b45309; }
    .status-completed { background: #d1fae5; color: #065f46; }
    .status-cancelled { background: #fee2e2; color: #991b1b; }
    .status-no_show { background: #f1f5f9; color: #475569; }

    .td-actions { white-space: nowrap; text-align: right; }
    .th-actions { text-align: right; }
    .btn-status-action {
      padding: 5px 9px; border-radius: 6px; font-size: 12px; font-weight: 600; cursor: pointer; border: 1px solid; margin-right: 4px;
    }
    .btn-in-consultation { background: #fef3c7; color: #b45309; border-color: #fde68a; }
    .btn-in-consultation:hover { background: #fde68a; }
    .btn-complete { background: #d1fae5; color: #065f46; border-color: #a7f3d0; }
    .btn-complete:hover { background: #a7f3d0; }

    .btn-table-edit, .btn-table-delete {
      padding: 6px 8px; border-radius: 6px; font-size: 12px; font-weight: 600; border: 1px solid #e2e8f0; background: #ffffff; cursor: pointer; margin-left: 4px;
    }
    .btn-table-edit:hover { border-color: #0d9488; color: #0d9488; }
    .btn-table-delete:hover { border-color: #ef4444; color: #ef4444; }

    .pagination-footer { display: flex; justify-content: space-between; align-items: center; padding: 14px 20px; border-top: 1px solid #f1f5f9; background: #fafbfc; font-size: 13px; color: #64748b; flex-wrap: wrap; gap: 10px; }
    .btn-pager { padding: 7px 14px; border-radius: 8px; border: 1px solid #cbd5e1; background: #ffffff; font-size: 12px; font-weight: 600; cursor: pointer; }
    .btn-pager:disabled { opacity: 0.5; cursor: not-allowed; }

    .table-loading, .table-empty { padding: 50px 20px; text-align: center; color: #64748b; display: flex; flex-direction: column; align-items: center; gap: 12px; }
    .empty-emoji { font-size: 36px; }
    .spinner { width: 24px; height: 24px; border: 3px solid #e2e8f0; border-top-color: #0d9488; border-radius: 50%; animation: spin 0.8s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }

    /* Modal */
    .modal-backdrop { position: fixed; inset: 0; background: rgba(15, 23, 42, 0.55); backdrop-filter: blur(4px); z-index: 9998; display: grid; place-items: center; padding: 16px; }
    .modal-dialog { background: #ffffff; width: min(600px, 100%); border-radius: 18px; padding: 26px; box-shadow: 0 25px 50px -12px rgba(15, 23, 42, 0.25); }
    .modal-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid #f1f5f9; padding-bottom: 12px; }
    .modal-head h3 { margin: 0; font-size: 18px; font-weight: 800; color: #0f172a; }
    .btn-close { background: transparent; border: none; font-size: 24px; color: #94a3b8; cursor: pointer; }
    .modal-form { display: flex; flex-direction: column; gap: 14px; }
    .form-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
    .form-group { display: flex; flex-direction: column; gap: 6px; }
    .form-group label { font-size: 13px; font-weight: 600; color: #334155; }
    .required { color: #ef4444; }
    .hint-text { font-size: 11px; color: #64748b; }
    .form-group input, .form-group select, .form-group textarea {
      padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 14px; outline: none; background: #ffffff; font-family: inherit;
    }
    .form-group input:focus, .form-group select:focus, .form-group textarea:focus { border-color: #0d9488; box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.15); }

    .modal-actions { margin-top: 20px; display: flex; justify-content: flex-end; gap: 12px; }
    .btn-secondary { padding: 10px 18px; border-radius: 8px; border: 1px solid #cbd5e1; background: #ffffff; color: #334155; font-weight: 600; cursor: pointer; }
    @media (max-width: 600px) { .form-grid-2 { grid-template-columns: 1fr; } }
  `]
})
export class AppointmentsComponent implements OnInit {
  private appointmentService = inject(AppointmentService);
  private petService = inject(PetService);
  private vetService = inject(VeterinarianService);
  private toast = inject(ToastService);

  appointments: Appointment[] = [];
  petOptions: Pet[] = [];
  vetOptions: Veterinarian[] = [];

  loading = true;
  saving = false;
  selectedStatus?: AppointmentStatus;

  currentPage = 1;
  pageSize = 10;
  totalRecords = 0;

  get totalPages(): number {
    return Math.max(1, Math.ceil(this.totalRecords / this.pageSize));
  }

  // Regla de negocio: Fecha y hora mínima es el momento actual formateado para input datetime-local
  get minDateTime(): string {
    const now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    return now.toISOString().slice(0, 16);
  }

  // Modal State
  modalOpen = false;
  isEditing = false;
  formData: any = {};

  // Cancel State
  confirmCancelOpen = false;
  appointmentToCancel: Appointment | null = null;

  ngOnInit(): void {
    this.loadCatalogs();
    this.loadPage(1);
  }

  loadCatalogs() {
    this.petService.list(1, 100).subscribe({
      next: res => this.petOptions = res.items
    });

    this.vetService.list(1, 50).subscribe({
      next: res => this.vetOptions = res.items
    });
  }

  loadPage(page: number) {
    this.currentPage = page;
    this.loading = true;

    this.appointmentService.list(page, this.pageSize, this.selectedStatus).subscribe({
      next: (res) => {
        this.appointments = res.items;
        this.totalRecords = res.total;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      }
    });
  }

  filterByStatus(status?: AppointmentStatus) {
    this.selectedStatus = status;
    this.loadPage(1);
  }

  translateStatus(status: AppointmentStatus): string {
    switch (status) {
      case 'scheduled': return 'Agendada';
      case 'in_consultation': return 'En Consulta';
      case 'completed': return 'Completada';
      case 'cancelled': return 'Cancelada';
      case 'no_show': return 'No se presentó';
      default: return status;
    }
  }

  openCreateModal() {
    this.isEditing = false;
    this.formData = {
      pet_id: this.petOptions.length ? this.petOptions[0].pet_id : undefined,
      vet_id: this.vetOptions.length ? this.vetOptions[0].vet_id : undefined,
      scheduled_at: this.minDateTime,
      duration_minutes: 30,
      reason: '',
      notes: ''
    };
    this.modalOpen = true;
  }

  openEditModal(a: Appointment) {
    this.isEditing = true;
    let scheduledFormatted = '';
    if (a.scheduled_at) {
      const d = new Date(a.scheduled_at);
      d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
      scheduledFormatted = d.toISOString().slice(0, 16);
    }

    this.formData = {
      ...a,
      scheduled_at: scheduledFormatted
    };
    this.modalOpen = true;
  }

  closeModalOnBackdrop(event: MouseEvent) {
    if ((event.target as HTMLElement).classList.contains('modal-backdrop')) {
      this.modalOpen = false;
    }
  }

  saveAppointment() {
    if (!this.formData.pet_id || !this.formData.vet_id || !this.formData.scheduled_at) {
      this.toast.error('Paciente, veterinario y fecha/hora son campos obligatorios.');
      return;
    }

    // Regla de negocio en frontend: No permitir agendar en el pasado para citas nuevas
    if (!this.isEditing) {
      const selected = new Date(this.formData.scheduled_at);
      const now = new Date();
      if (selected < now) {
        this.toast.warning('No se puede agendar una cita en una fecha u hora pasada.', 'Regla de Negocio');
        return;
      }
    }

    this.saving = true;

    if (this.isEditing && this.formData.appointment_id) {
      this.appointmentService.update(this.formData.appointment_id, this.formData).subscribe({
        next: (updated) => {
          this.toast.success(`Cita #${updated.appointment_id} reprogramada con éxito.`);
          this.saving = false;
          this.modalOpen = false;
          this.loadPage(this.currentPage);
        },
        error: (err) => {
          this.saving = false;
          this.toast.error(err.error?.detail || 'Error al actualizar la cita.');
        }
      });
    } else {
      this.appointmentService.create(this.formData).subscribe({
        next: (created) => {
          this.toast.success(`Cita #${created.appointment_id} agendada correctamente.`);
          this.saving = false;
          this.modalOpen = false;
          this.loadPage(1);
        },
        error: (err) => {
          this.saving = false;
          const msg = err.error?.detail || 'No se pudo agendar la cita. Verifique disponibilidad.';
          this.toast.error(msg);
        }
      });
    }
  }

  changeStatus(a: Appointment, newStatus: AppointmentStatus) {
    this.appointmentService.changeStatus(a.appointment_id, newStatus).subscribe({
      next: (res) => {
        a.status = res.status;
        this.toast.success(`Cita #${a.appointment_id} en estado: ${this.translateStatus(newStatus)}`);
      },
      error: (err) => {
        this.toast.error(err.error?.detail || 'No se pudo cambiar el estado de la cita.');
      }
    });
  }

  promptCancel(a: Appointment) {
    this.appointmentToCancel = a;
    this.confirmCancelOpen = true;
  }

  executeCancel() {
    if (!this.appointmentToCancel) return;

    this.appointmentService.changeStatus(this.appointmentToCancel.appointment_id, 'cancelled').subscribe({
      next: () => {
        this.toast.success('Cita cancelada con éxito.');
        this.confirmCancelOpen = false;
        this.appointmentToCancel = null;
        this.loadPage(this.currentPage);
      },
      error: () => {
        this.confirmCancelOpen = false;
        this.toast.error('No se pudo cancelar la cita.');
      }
    });
  }
}
