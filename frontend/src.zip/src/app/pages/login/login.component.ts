import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="login-wrapper">
      <div class="login-card">
        <!-- Logo y cabecera de la clínica -->
        <div class="login-header">
          <div class="clinic-badge">
            <span class="paw-icon">🐾</span>
          </div>
          <h1>VetCare Pro</h1>
          <p class="subtitle">Sistema de Gestión de Clínica Veterinaria</p>
        </div>

        <!-- Botones de Demostración Rápida  -->
        <div class="demo-section">
          <span class="demo-title">Acceso rápido para demostración:</span>
          <div class="demo-buttons">
            <button
              type="button"
              class="demo-btn admin"
              (click)="fillDemo('admin', 'Admin123!')"
              [disabled]="loading"
            >
              dmin
            </button>
            <button
              type="button"
              class="demo-btn vet"
              (click)="fillDemo('dra.gomez', 'Admin123!')"
              [disabled]="loading"
            >
              Veterinaria
            </button>
            <button
              type="button"
              class="demo-btn rec"
              (click)="fillDemo('recepcion', 'Admin123!')"
              [disabled]="loading"
            >
              Recepción
            </button>
          </div>
        </div>

        <!-- Formulario de inicio de sesión -->
        <form (ngSubmit)="submit()" class="login-form">
          <div class="form-group">
            <label for="username">Usuario o Identificador</label>
            <div class="input-icon-wrap">
              <svg class="input-icon" viewBox="0 0 20 20" fill="currentColor">
                <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd" />
              </svg>
              <input
                id="username"
                name="username"
                type="text"
                [(ngModel)]="username"
                placeholder="ej: admin o dra.gomez"
                required
                autocomplete="username"
                [disabled]="loading"
              />
            </div>
          </div>

          <div class="form-group">
            <label for="password">Contraseña</label>
            <div class="input-icon-wrap">
              <svg class="input-icon" viewBox="0 0 20 20" fill="currentColor">
                <path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd" />
              </svg>
              <input
                id="password"
                name="password"
                [type]="showPassword ? 'text' : 'password'"
                [(ngModel)]="password"
                placeholder="••••••••••••"
                required
                autocomplete="current-password"
                [disabled]="loading"
              />
              <button
                type="button"
                class="btn-toggle-pwd"
                (click)="showPassword = !showPassword"
                tabindex="-1"
              >
                {{ showPassword ? 'Ocultar' : 'Ver' }}
              </button>
            </div>
          </div>

          @if (error) {
            <div class="alert-error">
              <svg viewBox="0 0 20 20" fill="currentColor">
                <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
              </svg>
              <span>{{ error }}</span>
            </div>
          }

          <button
            type="submit"
            class="btn-submit"
            [disabled]="loading || !username || !password"
          >
            @if (loading) {
              <span class="spinner"></span>
              <span>Validando credenciales...</span>
            } @else {
              <span>Ingresar al Sistema</span>
              <svg viewBox="0 0 20 20" fill="currentColor">
                <path fill-rule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clip-rule="evenodd" />
              </svg>
            }
          </button>
        </form>

        <div class="login-footer">
          <span>Clínica Veterinaria &bull; PostgreSQL &bull; FastAPI &bull; Angular</span>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .login-wrapper {
      min-height: 100vh;
      display: grid;
      place-items: center;
      padding: 20px;
      background: radial-gradient(circle at 10% 20%, #042f2e 0%, #0f172a 90%);
      font-family: inherit;
    }
    .login-card {
      width: min(450px, 100%);
      background: #ffffff;
      border-radius: 20px;
      padding: 36px 32px;
      box-shadow: 0 25px 60px -15px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.1);
      animation: popIn 0.3s cubic-bezier(0.16, 1, 0.3, 1);
    }
    @keyframes popIn {
      from { transform: scale(0.96); opacity: 0; }
      to { transform: scale(1); opacity: 1; }
    }
    .login-header {
      text-align: center;
      margin-bottom: 24px;
    }
    .clinic-badge {
      width: 58px;
      height: 58px;
      margin: 0 auto 14px;
      border-radius: 16px;
      background: linear-gradient(135deg, #0d9488, #14b8a6);
      display: grid;
      place-items: center;
      box-shadow: 0 8px 20px rgba(13, 148, 136, 0.3);
    }
    .paw-icon {
      font-size: 30px;
    }
    .login-header h1 {
      margin: 0 0 6px 0;
      font-size: 26px;
      font-weight: 800;
      color: #0f172a;
      letter-spacing: -0.02em;
    }
    .subtitle {
      margin: 0;
      font-size: 14px;
      color: #64748b;
    }
    .demo-section {
      background: #f8fafc;
      border: 1px dashed #cbd5e1;
      border-radius: 12px;
      padding: 12px;
      margin-bottom: 24px;
    }
    .demo-title {
      display: block;
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      color: #64748b;
      margin-bottom: 8px;
      letter-spacing: 0.05em;
    }
    .demo-buttons {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 8px;
    }
    .demo-btn {
      padding: 7px 6px;
      font-size: 12px;
      font-weight: 600;
      border-radius: 8px;
      border: 1px solid #e2e8f0;
      background: #ffffff;
      color: #334155;
      cursor: pointer;
      transition: all 0.15s ease;
      white-space: nowrap;
    }
    .demo-btn:hover {
      transform: translateY(-1px);
    }
    .demo-btn.admin:hover { background: #fef3c7; color: #b45309; border-color: #fde68a; }
    .demo-btn.vet:hover { background: #ccfbf1; color: #0f766e; border-color: #99f6e4; }
    .demo-btn.rec:hover { background: #dbeafe; color: #1e40af; border-color: #bfdbfe; }

    .login-form {
      display: flex;
      flex-direction: column;
      gap: 18px;
    }
    .form-group {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .form-group label {
      font-size: 13px;
      font-weight: 600;
      color: #334155;
    }
    .input-icon-wrap {
      position: relative;
      display: flex;
      align-items: center;
    }
    .input-icon {
      position: absolute;
      left: 12px;
      width: 18px;
      height: 18px;
      color: #94a3b8;
      pointer-events: none;
    }
    .input-icon-wrap input {
      width: 100%;
      padding: 12px 14px 12px 38px;
      border-radius: 10px;
      border: 1px solid #cbd5e1;
      font-size: 14px;
      color: #0f172a;
      background: #ffffff;
      transition: border-color 0.15s, box-shadow 0.15s;
    }
    .input-icon-wrap input:focus {
      outline: none;
      border-color: #0d9488;
      box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.15);
    }
    .btn-toggle-pwd {
      position: absolute;
      right: 10px;
      background: transparent;
      border: none;
      font-size: 12px;
      color: #64748b;
      font-weight: 600;
      cursor: pointer;
      padding: 4px 6px;
    }
    .btn-toggle-pwd:hover {
      color: #0f172a;
    }
    .alert-error {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 11px 14px;
      border-radius: 10px;
      background: #fee2e2;
      border: 1px solid #fecaca;
      color: #b91c1c;
      font-size: 13px;
    }
    .alert-error svg {
      width: 18px;
      height: 18px;
      flex-shrink: 0;
    }
    .btn-submit {
      margin-top: 8px;
      padding: 13px 20px;
      border-radius: 10px;
      border: none;
      background: linear-gradient(135deg, #0d9488, #0f766e);
      color: #ffffff;
      font-size: 15px;
      font-weight: 700;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      box-shadow: 0 4px 14px rgba(13, 148, 136, 0.35);
      transition: all 0.15s ease;
    }
    .btn-submit:hover:not(:disabled) {
      background: linear-gradient(135deg, #0f766e, #115e59);
      box-shadow: 0 6px 18px rgba(13, 148, 136, 0.45);
      transform: translateY(-1px);
    }
    .btn-submit:disabled {
      opacity: 0.65;
      cursor: not-allowed;
    }
    .btn-submit svg {
      width: 18px;
      height: 18px;
    }
    .spinner {
      width: 16px;
      height: 16px;
      border: 2px solid rgba(255, 255, 255, 0.3);
      border-top-color: #ffffff;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    .login-footer {
      margin-top: 24px;
      text-align: center;
      font-size: 11px;
      color: #94a3b8;
    }
  `]
})
export class LoginComponent {
  auth = inject(AuthService);
  router = inject(Router);
  toast = inject(ToastService);

  username = '';
  password = '';
  showPassword = false;
  loading = false;
  error = '';

  fillDemo(u: string, p: string) {
    this.username = u;
    this.password = p;
    this.error = '';
    this.submit();
  }

  submit() {
    if (!this.username || !this.password) return;

    this.loading = true;
    this.error = '';

    this.auth.login(this.username, this.password).subscribe({
      next: (res) => {
        this.toast.success(`Bienvenido/a, ${res.user.username} (${res.user.role})`, 'Acceso Correcto');
        this.router.navigate(['/dashboard']);
      },
      error: (err) => {
        this.loading = false;
        if (err.status === 401) {
          this.error = 'Usuario o contraseña incorrectos. Verifique sus credenciales.';
        } else if (err.status === 403) {
          this.error = 'Usuario inactivo o sin permisos para iniciar sesión.';
        } else if (err.status === 422) {
          this.error = 'Formato de credenciales inválido.';
        } else if (err.status >= 500) {
          this.error = 'Error interno en el servidor backend o base de datos PostgreSQL.';
        } else {
          this.error = `No se pudo conectar con la API en ${this.auth.apiUrl}. Asegúrate de reiniciar el servidor backend (Ctrl+C y volver a ejecutar uvicorn).`;
        }
      }
    });
  }
}