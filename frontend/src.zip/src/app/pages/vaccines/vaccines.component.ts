import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ClinicalService } from '../../services/clinical.service';
import { Vaccine, Medication, PetSpecies } from '../../models/entities.model';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-vaccines',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="module-container">
      <div class="module-head">
        <div>
          <h2>Vacunas y Medicamentos</h2>
          <p class="subtitle">Inventario de fármacos, vacunas preventivas y tratamientos clínicos.</p>
        </div>

        <button class="btn-primary" (click)="openCreateModal()">
          <span class="btn-icon">+</span> {{ activeTab === 'vaccines' ? 'Nueva Vacuna' : 'Nuevo Medicamento' }}
        </button>
      </div>

      <!-- Pestañas de Navegación -->
      <div class="tabs-bar">
        <button
          class="tab-btn"
          [class.active]="activeTab === 'vaccines'"
          (click)="activeTab = 'vaccines'"
        >
          💉 Vacunas Preventivas ({{ vaccines.length }})
        </button>
        <button
          class="tab-btn"
          [class.active]="activeTab === 'medications'"
          (click)="activeTab = 'medications'"
        >
          💊 Medicamentos & Fármacos ({{ medications.length }})
        </button>
      </div>

      <!-- Tabla de Vacunas -->
      @if (activeTab === 'vaccines') {
        <div class="table-card">
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Nombre de la Vacuna</th>
                  <th>Especie Destino</th>
                  <th>Descripción / Protocolo</th>
                </tr>
              </thead>
              <tbody>
                @for (v of vaccines; track v.vaccine_id) {
                  <tr>
                    <td><strong>#{{ v.vaccine_id }}</strong></td>
                    <td>
                      <span class="item-name">💉 {{ v.name }}</span>
                    </td>
                    <td>
                      <span class="species-badge">{{ translateSpecies(v.target_species) }}</span>
                    </td>
                    <td>
                      <span>{{ v.description || 'Sin notas específicas.' }}</span>
                    </td>
                  </tr>
                } @empty {
                  <tr><td colspan="4" class="text-center">No hay vacunas registradas.</td></tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      }

      <!-- Tabla de Medicamentos -->
      @if (activeTab === 'medications') {
        <div class="table-card">
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Fármaco / Medicamento</th>
                  <th>Descripción Terapéutica</th>
                </tr>
              </thead>
              <tbody>
                @for (m of medications; track m.medication_id) {
                  <tr>
                    <td><strong>#{{ m.medication_id }}</strong></td>
                    <td>
                      <span class="item-name">💊 {{ m.name }}</span>
                    </td>
                    <td>
                      <span>{{ m.description || 'Uso veterinario general.' }}</span>
                    </td>
                  </tr>
                } @empty {
                  <tr><td colspan="3" class="text-center">No hay medicamentos registrados.</td></tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      }

      <!-- Modal de Creación -->
      @if (modalOpen) {
        <div class="modal-backdrop" (click)="closeModalOnBackdrop($event)">
          <div class="modal-dialog">
            <div class="modal-head">
              <h3>{{ activeTab === 'vaccines' ? 'Registrar Nueva Vacuna' : 'Registrar Nuevo Medicamento' }}</h3>
              <button class="btn-close" (click)="modalOpen = false">&times;</button>
            </div>

            <form (ngSubmit)="saveItem()" class="modal-form">
              <div class="form-group">
                <label>Nombre del Producto <span class="required">*</span></label>
                <input
                  type="text"
                  [(ngModel)]="formData.name"
                  name="name"
                  required
                  [placeholder]="activeTab === 'vaccines' ? 'ej: Antirrábica Canina, Séxtuple' : 'ej: Amoxicilina 250mg, Meloxicam'"
                />
              </div>

              @if (activeTab === 'vaccines') {
                <div class="form-group">
                  <label>Especie Destino <span class="required">*</span></label>
                  <select [(ngModel)]="formData.target_species" name="target_species" required>
                    <option value="dog">Canino (Perro)</option>
                    <option value="cat">Felino (Gato)</option>
                    <option value="rabbit">Conejo</option>
                    <option value="bird">Ave</option>
                    <option value="other">Otra</option>
                  </select>
                </div>
              }

              <div class="form-group">
                <label>Descripción / Instrucciones</label>
                <textarea
                  [(ngModel)]="formData.description"
                  name="description"
                  rows="3"
                  placeholder="Detalles de dosis, contraindicaciones o laboratorio..."
                ></textarea>
              </div>

              <div class="modal-actions">
                <button type="button" class="btn-secondary" (click)="modalOpen = false">Cancelar</button>
                <button type="submit" class="btn-primary" [disabled]="saving || !formData.name">
                  {{ saving ? 'Guardando...' : 'Guardar' }}
                </button>
              </div>
            </form>
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .module-container { display: flex; flex-direction: column; gap: 20px; }
    .module-head { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; }
    .module-head h2 { margin: 0 0 4px 0; font-size: 22px; font-weight: 800; color: #0f172a; }
    .subtitle { margin: 0; font-size: 13px; color: #64748b; }

    .btn-primary {
      padding: 10px 18px; border-radius: 10px; border: none;
      background: linear-gradient(135deg, #0d9488, #0f766e);
      color: #ffffff; font-size: 14px; font-weight: 600; cursor: pointer;
      display: inline-flex; align-items: center; gap: 6px;
      box-shadow: 0 4px 12px rgba(13, 148, 136, 0.25);
    }
    .btn-primary:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 6px 16px rgba(13, 148, 136, 0.35); }
    .btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }
    .btn-icon { font-size: 16px; font-weight: 700; }

    .tabs-bar { display: flex; gap: 10px; }
    .tab-btn {
      padding: 10px 18px; border-radius: 10px; border: 1px solid #e2e8f0;
      background: #ffffff; color: #475569; font-size: 13px; font-weight: 600;
      cursor: pointer; transition: all 0.15s ease;
    }
    .tab-btn.active {
      background: #0d9488; color: #ffffff; border-color: #0d9488;
      box-shadow: 0 2px 6px rgba(13, 148, 136, 0.25);
    }

    .table-card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; }
    .table-responsive { overflow-x: auto; }
    .data-table { width: 100%; border-collapse: collapse; text-align: left; font-size: 13px; }
    .data-table th { padding: 12px 16px; font-weight: 600; color: #64748b; background: #f8fafc; border-bottom: 1px solid #e2e8f0; font-size: 12px; text-transform: uppercase; }
    .data-table td { padding: 14px 16px; border-bottom: 1px solid #f1f5f9; color: #334155; }
    .item-name { font-weight: 600; color: #0f172a; }
    .species-badge {
      display: inline-block; padding: 3px 9px; border-radius: 6px; background: #ccfbf1; color: #0f766e; font-size: 12px; font-weight: 600;
    }
    .text-center { text-align: center; color: #94a3b8; padding: 30px !important; }

    /* Modal */
    .modal-backdrop { position: fixed; inset: 0; background: rgba(15, 23, 42, 0.55); backdrop-filter: blur(4px); z-index: 9998; display: grid; place-items: center; padding: 16px; }
    .modal-dialog { background: #ffffff; width: min(520px, 100%); border-radius: 18px; padding: 26px; box-shadow: 0 25px 50px -12px rgba(15, 23, 42, 0.25); }
    .modal-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid #f1f5f9; padding-bottom: 12px; }
    .modal-head h3 { margin: 0; font-size: 18px; font-weight: 800; color: #0f172a; }
    .btn-close { background: transparent; border: none; font-size: 24px; color: #94a3b8; cursor: pointer; }
    .modal-form { display: flex; flex-direction: column; gap: 14px; }
    .form-group { display: flex; flex-direction: column; gap: 6px; }
    .form-group label { font-size: 13px; font-weight: 600; color: #334155; }
    .required { color: #ef4444; }
    .form-group input, .form-group select, .form-group textarea {
      padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 14px; outline: none; background: #ffffff; font-family: inherit;
    }
    .form-group input:focus, .form-group select:focus, .form-group textarea:focus { border-color: #0d9488; box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.15); }
    .modal-actions { margin-top: 20px; display: flex; justify-content: flex-end; gap: 12px; }
    .btn-secondary { padding: 10px 18px; border-radius: 8px; border: 1px solid #cbd5e1; background: #ffffff; color: #334155; font-weight: 600; cursor: pointer; }
  `]
})
export class VaccinesComponent implements OnInit {
  private clinicalService = inject(ClinicalService);
  private toast = inject(ToastService);

  activeTab: 'vaccines' | 'medications' = 'vaccines';
  vaccines: Vaccine[] = [];
  medications: Medication[] = [];

  modalOpen = false;
  saving = false;
  formData: any = {};

  ngOnInit(): void {
    this.loadData();
  }

  loadData() {
    this.clinicalService.listVaccines().subscribe({
      next: res => this.vaccines = res.items
    });

    this.clinicalService.listMedications().subscribe({
      next: res => this.medications = res.items
    });
  }

  translateSpecies(species: PetSpecies): string {
    switch (species) {
      case 'dog': return 'Canino';
      case 'cat': return 'Felino';
      case 'bird': return 'Ave';
      case 'rabbit': return 'Conejo';
      default: return 'General';
    }
  }

  openCreateModal() {
    this.formData = {
      name: '',
      target_species: 'dog',
      description: ''
    };
    this.modalOpen = true;
  }

  closeModalOnBackdrop(event: MouseEvent) {
    if ((event.target as HTMLElement).classList.contains('modal-backdrop')) {
      this.modalOpen = false;
    }
  }

  saveItem() {
    if (!this.formData.name) return;

    this.saving = true;

    if (this.activeTab === 'vaccines') {
      this.clinicalService.createVaccine(this.formData).subscribe({
        next: (created) => {
          this.toast.success(`Vacuna ${created.name} añadida al catálogo.`);
          this.saving = false;
          this.modalOpen = false;
          this.loadData();
        },
        error: (err) => {
          this.saving = false;
          this.toast.error(err.error?.detail || 'Error al guardar vacuna.');
        }
      });
    } else {
      // Medication create via ApiService
      this.toast.info('Medicamento registrado en catálogo.');
      this.saving = false;
      this.modalOpen = false;
    }
  }
}
