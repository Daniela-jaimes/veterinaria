import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VeterinarianService } from '../../services/veterinarian.service';
import { Veterinarian, Speciality } from '../../models/entities.model';
import { ToastService } from '../../services/toast.service';
import { ConfirmModalComponent } from '../../components/confirm-modal/confirm-modal.component';

@Component({
  selector: 'app-veterinarians',
  standalone: true,
  imports: [CommonModule, FormsModule, ConfirmModalComponent],
  template: `
    <div class="module-container">
      <div class="module-head">
        <div>
          <h2>Equipo Médico Veterinario</h2>
          <p class="subtitle">Especialistas habilitados para atención clínica y procedimientos.</p>
        </div>

        <button class="btn-primary" (click)="openCreateModal()">
          <span class="btn-icon">+</span> Nuevo Médico
        </button>
      </div>

      <!-- Tabla de Veterinarios -->
      <div class="table-card">
        @if (loading) {
          <div class="table-loading">
            <span class="spinner"></span>
            <span>Cargando cuerpo médico...</span>
          </div>
        } @else if (vets.length === 0) {
          <div class="table-empty">
            <span class="empty-emoji">🩺</span>
            <h3>No hay veterinarios registrados</h3>
            <p>Registra al primer especialista del centro veterinario.</p>
            <button class="btn-primary" (click)="openCreateModal()">+ Registrar Veterinario</button>
          </div>
        } @else {
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Veterinario</th>
                  <th>Matrícula / CMVP</th>
                  <th>Especialidad</th>
                  <th>Contacto</th>
                  <th>Email</th>
                  <th>Estado</th>
                  <th class="th-actions">Acciones</th>
                </tr>
              </thead>
              <tbody>
                @for (v of vets; track v.vet_id) {
                  <tr>
                    <td>
                      <div class="vet-name-cell">
                        <div class="avatar-vet">🩺</div>
                        <div>
                          <strong>Dr(a). {{ v.first_name }} {{ v.last_name }}</strong>
                          <span class="vet-id-sub">ID: #{{ v.vet_id }}</span>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span class="license-tag">{{ v.license_number }}</span>
                    </td>
                    <td>
                      <span class="speciality-badge">
                        {{ v.speciality?.name || getSpecialityName(v.speciality_id) }}
                      </span>
                    </td>
                    <td>
                      <span>📞 {{ v.phone || '—' }}</span>
                    </td>
                    <td>
                      <span>{{ v.email || '—' }}</span>
                    </td>
                    <td>
                      <span class="badge" [class.badge-active]="v.is_active" [class.badge-inactive]="!v.is_active">
                        {{ v.is_active ? 'Activo' : 'Inactivo' }}
                      </span>
                    </td>
                    <td class="td-actions">
                      <button class="btn-table-edit" (click)="openEditModal(v)" title="Editar">
                        ✏️ Editar
                      </button>
                      <button class="btn-table-delete" (click)="promptDelete(v)" title="Eliminar">
                        🗑️ Eliminar
                      </button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
      </div>

      <!-- Modal Crear/Editar Veterinario -->
      @if (modalOpen) {
        <div class="modal-backdrop" (click)="closeModalOnBackdrop($event)">
          <div class="modal-dialog">
            <div class="modal-head">
              <h3>{{ isEditing ? 'Editar Especialista' : 'Registrar Nuevo Veterinario' }}</h3>
              <button class="btn-close" (click)="modalOpen = false">&times;</button>
            </div>

            <form (ngSubmit)="saveVet()" class="modal-form">
              <div class="form-grid-2">
                <div class="form-group">
                  <label>Nombres <span class="required">*</span></label>
                  <input type="text" [(ngModel)]="formData.first_name" name="first_name" required placeholder="ej: Andrea" />
                </div>

                <div class="form-group">
                  <label>Apellidos <span class="required">*</span></label>
                  <input type="text" [(ngModel)]="formData.last_name" name="last_name" required placeholder="ej: Gómez Ramos" />
                </div>
              </div>

              <div class="form-grid-2">
                <div class="form-group">
                  <label>N° Colegiatura / Matrícula <span class="required">*</span></label>
                  <input type="text" [(ngModel)]="formData.license_number" name="license_number" required placeholder="ej: CMVP-10293" />
                </div>

                <div class="form-group">
                  <label>Especialidad <span class="required">*</span></label>
                  <select [(ngModel)]="formData.speciality_id" name="speciality_id" required>
                    <option [ngValue]="undefined" disabled>-- Selecciona Especialidad --</option>
                    @for (s of specialities; track s.speciality_id) {
                      <option [ngValue]="s.speciality_id">{{ s.name }}</option>
                    }
                  </select>
                </div>
              </div>

              <div class="form-grid-2">
                <div class="form-group">
                  <label>Teléfono de Contacto</label>
                  <input type="tel" [(ngModel)]="formData.phone" name="phone" placeholder="ej: +51 987654321" />
                </div>

                <div class="form-group">
                  <label>Correo Electrónico</label>
                  <input type="email" [(ngModel)]="formData.email" name="email" placeholder="ej: dra.gomez@clinica.com" />
                </div>
              </div>

              @if (isEditing) {
                <div class="form-check">
                  <input type="checkbox" id="is_active_vet" [(ngModel)]="formData.is_active" name="is_active" />
                  <label for="is_active_vet">Veterinario Activo para Consultas</label>
                </div>
              }

              <div class="modal-actions">
                <button type="button" class="btn-secondary" (click)="modalOpen = false">Cancelar</button>
                <button
                  type="submit"
                  class="btn-primary"
                  [disabled]="saving || !formData.first_name || !formData.last_name || !formData.license_number || !formData.speciality_id"
                >
                  {{ saving ? 'Guardando...' : (isEditing ? 'Actualizar' : 'Registrar') }}
                </button>
              </div>
            </form>
          </div>
        </div>
      }

      <app-confirm-modal
        [isOpen]="confirmDeleteOpen"
        title="¿Desactivar Médico Veterinario?"
        [message]="'¿Estás seguro de que deseas desactivar a ' + vetToDelete?.first_name + ' ' + vetToDelete?.last_name + '?'"
        confirmText="Sí, Desactivar"
        (confirm)="executeDelete()"
        (cancel)="confirmDeleteOpen = false"
      />
    </div>
  `,
  styles: [`
    .module-container { display: flex; flex-direction: column; gap: 20px; }
    .module-head { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; }
    .module-head h2 { margin: 0 0 4px 0; font-size: 22px; font-weight: 800; color: #0f172a; }
    .subtitle { margin: 0; font-size: 13px; color: #64748b; }

    .btn-primary {
      padding: 10px 18px; border-radius: 10px; border: none;
      background: linear-gradient(135deg, #0d9488, #0f766e);
      color: #ffffff; font-size: 14px; font-weight: 600; cursor: pointer;
      display: inline-flex; align-items: center; gap: 6px;
      box-shadow: 0 4px 12px rgba(13, 148, 136, 0.25);
    }
    .btn-primary:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 6px 16px rgba(13, 148, 136, 0.35); }
    .btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }
    .btn-icon { font-size: 16px; font-weight: 700; }

    .table-card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; }
    .table-responsive { overflow-x: auto; }
    .data-table { width: 100%; border-collapse: collapse; text-align: left; font-size: 13px; }
    .data-table th { padding: 12px 16px; font-weight: 600; color: #64748b; background: #f8fafc; border-bottom: 1px solid #e2e8f0; font-size: 12px; text-transform: uppercase; }
    .data-table td { padding: 14px 16px; border-bottom: 1px solid #f1f5f9; color: #334155; }

    .vet-name-cell { display: flex; align-items: center; gap: 12px; }
    .avatar-vet {
      width: 38px; height: 38px; border-radius: 10px; background: #f3e8ff; display: grid; place-items: center; font-size: 18px; flex-shrink: 0;
    }
    .vet-id-sub { font-size: 11px; color: #94a3b8; display: block; }
    .license-tag {
      font-family: monospace; font-size: 12px; background: #f8fafc; border: 1px solid #cbd5e1; padding: 2px 6px; border-radius: 6px;
    }
    .speciality-badge {
      display: inline-block; padding: 4px 10px; border-radius: 6px; background: #ccfbf1; color: #0f766e; font-size: 12px; font-weight: 600;
    }

    .badge { display: inline-block; padding: 3px 9px; border-radius: 999px; font-size: 11px; font-weight: 600; }
    .badge-active { background: #d1fae5; color: #065f46; }
    .badge-inactive { background: #fee2e2; color: #991b1b; }

    .td-actions { white-space: nowrap; text-align: right; }
    .th-actions { text-align: right; }
    .btn-table-edit, .btn-table-delete {
      padding: 6px 10px; border-radius: 6px; font-size: 12px; font-weight: 600; border: 1px solid #e2e8f0; background: #ffffff; cursor: pointer; margin-left: 6px;
    }
    .btn-table-edit:hover { border-color: #0d9488; color: #0d9488; background: #f0fdfa; }
    .btn-table-delete:hover { border-color: #ef4444; color: #ef4444; background: #fef2f2; }

    .table-loading, .table-empty { padding: 50px 20px; text-align: center; color: #64748b; display: flex; flex-direction: column; align-items: center; gap: 12px; }
    .empty-emoji { font-size: 36px; }
    .spinner { width: 24px; height: 24px; border: 3px solid #e2e8f0; border-top-color: #0d9488; border-radius: 50%; animation: spin 0.8s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }

    /* Modal */
    .modal-backdrop { position: fixed; inset: 0; background: rgba(15, 23, 42, 0.55); backdrop-filter: blur(4px); z-index: 9998; display: grid; place-items: center; padding: 16px; }
    .modal-dialog { background: #ffffff; width: min(600px, 100%); border-radius: 18px; padding: 26px; box-shadow: 0 25px 50px -12px rgba(15, 23, 42, 0.25); }
    .modal-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid #f1f5f9; padding-bottom: 12px; }
    .modal-head h3 { margin: 0; font-size: 18px; font-weight: 800; color: #0f172a; }
    .btn-close { background: transparent; border: none; font-size: 24px; color: #94a3b8; cursor: pointer; }
    .modal-form { display: flex; flex-direction: column; gap: 14px; }
    .form-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
    .form-group { display: flex; flex-direction: column; gap: 6px; }
    .form-group label { font-size: 13px; font-weight: 600; color: #334155; }
    .required { color: #ef4444; }
    .form-group input, .form-group select {
      padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 14px; outline: none; background: #ffffff;
    }
    .form-group input:focus, .form-group select:focus { border-color: #0d9488; box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.15); }
    .form-check { display: flex; align-items: center; gap: 8px; margin-top: 4px; }
    .form-check input { width: auto; }
    .form-check label { font-size: 13px; color: #334155; }

    .modal-actions { margin-top: 20px; display: flex; justify-content: flex-end; gap: 12px; }
    .btn-secondary { padding: 10px 18px; border-radius: 8px; border: 1px solid #cbd5e1; background: #ffffff; color: #334155; font-weight: 600; cursor: pointer; }
    @media (max-width: 600px) { .form-grid-2 { grid-template-columns: 1fr; } }
  `]
})
export class VeterinariansComponent implements OnInit {
  private vetService = inject(VeterinarianService);
  private toast = inject(ToastService);

  vets: Veterinarian[] = [];
  specialities: Speciality[] = [];
  specialityMap = new Map<number, string>();

  loading = true;
  saving = false;

  modalOpen = false;
  isEditing = false;
  formData: any = {};

  confirmDeleteOpen = false;
  vetToDelete: Veterinarian | null = null;

  ngOnInit(): void {
    this.loadSpecialities();
    this.loadVets();
  }

  loadSpecialities() {
    this.vetService.getSpecialities(1, 100).subscribe({
      next: (res) => {
        this.specialities = res.items;
        res.items.forEach(s => this.specialityMap.set(s.speciality_id, s.name));
      }
    });
  }

  loadVets() {
    this.loading = true;
    this.vetService.list(1, 50).subscribe({
      next: (res) => {
        this.vets = res.items;
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }

  getSpecialityName(id: number): string {
    return this.specialityMap.get(id) || `Especialidad #${id}`;
  }

  openCreateModal() {
    this.isEditing = false;
    this.formData = {
      speciality_id: this.specialities.length ? this.specialities[0].speciality_id : undefined,
      first_name: '',
      last_name: '',
      license_number: '',
      phone: '',
      email: '',
      is_active: true
    };
    this.modalOpen = true;
  }

  openEditModal(v: Veterinarian) {
    this.isEditing = true;
    this.formData = { ...v };
    this.modalOpen = true;
  }

  closeModalOnBackdrop(event: MouseEvent) {
    if ((event.target as HTMLElement).classList.contains('modal-backdrop')) {
      this.modalOpen = false;
    }
  }

  saveVet() {
    if (!this.formData.first_name || !this.formData.last_name || !this.formData.license_number || !this.formData.speciality_id) {
      this.toast.error('Todos los campos marcados con asterisco son requeridos.');
      return;
    }

    this.saving = true;

    if (this.isEditing && this.formData.vet_id) {
      this.vetService.update(this.formData.vet_id, this.formData).subscribe({
        next: (updated) => {
          this.toast.success(`Veterinario Dr(a). ${updated.first_name} actualizado.`);
          this.saving = false;
          this.modalOpen = false;
          this.loadVets();
        },
        error: (err) => {
          this.saving = false;
          this.toast.error(err.error?.detail || 'Error al actualizar veterinario.');
        }
      });
    } else {
      this.vetService.create(this.formData).subscribe({
        next: (created) => {
          this.toast.success(`Dr(a). ${created.first_name} registrado correctamente.`);
          this.saving = false;
          this.modalOpen = false;
          this.loadVets();
        },
        error: (err) => {
          this.saving = false;
          this.toast.error(err.error?.detail || 'No se pudo registrar al especialista.');
        }
      });
    }
  }

  promptDelete(v: Veterinarian) {
    this.vetToDelete = v;
    this.confirmDeleteOpen = true;
  }

  executeDelete() {
    if (!this.vetToDelete) return;

    this.vetService.remove(this.vetToDelete.vet_id).subscribe({
      next: () => {
        this.toast.success(`Veterinario desactivado.`);
        this.confirmDeleteOpen = false;
        this.vetToDelete = null;
        this.loadVets();
      },
      error: (err) => {
        this.confirmDeleteOpen = false;
        this.toast.error(err.error?.detail || 'No se pudo desactivar al veterinario.');
      }
    });
  }
}
